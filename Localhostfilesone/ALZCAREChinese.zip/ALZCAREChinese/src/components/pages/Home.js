import React from 'react';
import '../../App.css';
import HeroSection from '../HeroSection';
//importing all dependiencies, libraries, and subsite js pages by category- Hamilton Nguyen 10/19/2020

// This function Home page serves to call herosection to return a the layout of herosection for the front page website.- Hamilton Nguyen 10/19/2020
function Home() {
  return (
    <>
      <HeroSection />
    </>
  );
}

export default Home;