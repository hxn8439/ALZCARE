/*@flow*/
import React from 'react';
import './Cards.css';
import CardItem from './CardItem';
//importing all dependiencies, libraries, and subsite js pages by category- Hamilton Nguyen 10/19/2020

//card function are created to return static cards that goes onto the dementia info page. Withinn the function, a total of three cards with disignated classNames are created.- Hamilton Nguyen 10/19/2020
function Cards() {
  return (
    <div className='cards'>
      <h1>痴呆症信息</h1>
      <div className='cards__container'>
        <div className='cards__wrapper'>
          <ul className='cards__items'>
            <CardItem
              src='images/img-9.jpg'
              text='阿尔茨海默氏病与遗传，生活方式和环境因素相关，这些因素会随着时间影响大脑细胞。在疾病的初始阶段，可以看到健忘和轻度混乱。随着时间的流逝，最近的记忆也开始消失。晚期症状因人而异。阿尔茨海默氏病无法治愈。药物可以暂时减轻某些症状或减慢某些人的病情进展。'
              label='阿尔茨海默氏病'
              path='/services'
            />
            <CardItem
              src='images/img-2.jpg'
              text='一组影响记忆，思维并干扰日常生活的症状。'
              label='痴呆'
              path='/services'
            />
            <CardItem
              src='images/img-2.jpg'
              text='科学家在寻找有助于诊断，治疗甚至预防老年痴呆症和相关痴呆症的潜在新方法方面取得了长足的进步。这些进步之所以成为可能，是因为数千人参加了临床试验和其他研究。'
              label='痴呆症研究和临床试验'
              path='/services'
            />
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Cards;