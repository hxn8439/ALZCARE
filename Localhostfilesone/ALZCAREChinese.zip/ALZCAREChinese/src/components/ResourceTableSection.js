import React from 'react';
import { Table, Thead, Tbody, Tr, Th, Td } from 'react-super-responsive-table';
import './ResourceTableSection.css';

export default function ResourceTableSection(props) {
  return (
    <Table>
      <Thead>
        <Tr>
          <Th>资源资源</Th>
          <Th>地址</Th>
          <Th>电话</Th>
          <Th>网站</Th>
          <Th>类型</Th>
          
        </Tr>
      </Thead>
      <Tbody>
        <Tr>
          <Td>Chinese Seniors Association of Houston</Td>
          <Td></Td>
          <Td></Td>
          <Td>https://csahouston.wordpress.com</Td>
          <Td></Td>
          
        </Tr>
        <Tr>
          <Td>Asian American Health Coalition</Td>
          <Td></Td>
          <Td></Td>
          <Td>http://asianhealthhouston.org</Td>
          <Td></Td>
          
        </Tr>
        <Tr>
          <Td>Austin Chinese-American Network (ACAN)</Td>
          <Td></Td>
          <Td></Td>
          <Td>https://www.austinchineseamericannetwork.org</Td>
          <Td></Td>
          
        </Tr>
        <Tr>
          <Td>Chinese Society of Austin (CSA)</Td>
          <Td></Td>
          <Td></Td>
          <Td>http://csaustin.org</Td>
          <Td></Td>
          
        </Tr>
        <Tr>
          <Td>Asian American Resource Center</Td>
          <Td></Td>
          <Td></Td>
          <Td>http://austintexas.gov/department/asian-american-resource-center</Td>
          <Td></Td>
          
        </Tr>
        <Tr>
          <Td>OCA - Greater Houston</Td>
          <Td>9800 Town Park Dr #142, Houston, TX 77036</Td>
          <Td>info@ocahouston.org</Td>
          <Td>http://www.ocahouston.org</Td>
          <Td></Td>
          
        </Tr>
        <Tr>
          <Td>Chinese Civic Center</Td>
          <Td>5905 Sovereign Dr, Houston, TX 77036</Td>
          <Td></Td>
          <Td>https://www.chineseciviccenter.org/</Td>
          <Td></Td>
          
        </Tr>
        <Tr>
          <Td>CCC (Chinese Community Center)</Td>
          <Td>9800 Town Park Dr, Houston, TX 77036</Td>
          <Td>(713) 271-6100</Td>
          <Td>https://ccchouston.org</Td>
          <Td></Td>
          
        </Tr>
        <Tr>
          <Td>Chinese Baptist Church</Td>
          <Td>900 Brogden Rd, Houston, TX 77024</Td>
          <Td>(713) 461-0963</Td>
          <Td>https://www.cbchouston.org/chindex.html</Td>
          <Td></Td>
          
        </Tr>
        <Tr>
          <Td>Everspring Assisted Living</Td>
          <Td>6501 Westline Dr, Houston, TX 77036</Td>
          <Td>(713) 988-2843</Td>
          <Td>https://everspring-living.com/</Td>
          <Td></Td>
          
        </Tr>
        <Tr>
          <Td>Turtlewood Manor</Td>
          <Td>6955 Turtlewood Dr, Houston, TX 77072</Td>
          <Td>(713) 979-8242</Td>
          <Td>https://turtlewoodseniorliving.net/</Td>
          <Td></Td>
          
        </Tr>
      </Tbody>
    </Table>
  );
} // Static list of dementia care facilities to display below the map - still need to dynamically pull from Firebase