import React from 'react';
import { Table, Thead, Tbody, Tr, Th, Td } from 'react-super-responsive-table';
import './ResourceTableSection.css';

export default function ResourceTableSection(props) {
  return (
    <Table>
      <Thead>
        <Tr>
          <Th>자원</Th>
          <Th>주소</Th>
          <Th>전화</Th>
          <Th>웹 사이트</Th>
          <Th>유형</Th>
          
        </Tr>
      </Thead>
      <Tbody>
        <Tr>
          <Td>Carrollton Health & Rehabilitation Center</Td>
          <Td>1618 Kirby Rd, Carrollton, TX 75006</Td>
          <Td>(972) 245-1573</Td>
          <Td>https://carrolltonhealth.com</Td>
          <Td>Nursing home</Td>
          
        </Tr>
        <Tr>
          <Td>Grace Adult Day Care Center (은혜복지건강센터)</Td>
          <Td>1870 Crown Dr #1520, Farmers Branch, TX 75234</Td>
          <Td>(972) 506-0177</Td>
          <Td>http://gracedahs.org/</Td>
          <Td>Day care center</Td>
          
        </Tr>
        <Tr>
          <Td>Korean Home Health Care (한국 홈케어)</Td>
          <Td>1908 Royal Ln Ste 100, Dallas, TX 75229</Td>
          <Td>(972) 241-9996</Td>
          <Td>http://khhcusa.com/index.php?mid=page_hCmK31</Td>
          <Td>Home care</Td>
          
        </Tr>
        <Tr>
          <Td>Korean Cultural Center of Dallas</Td>
          <Td>11500 N Stemmons Fwy, Dallas, TX 75229</Td>
          <Td>(972) 241-4524</Td>
          <Td>https://www.kccus.org</Td>
          <Td>Community center</Td>
          
        </Tr>
        <Tr>
          <Td>Korean Senior Citizens Association (달라스 노인회)</Td>
          <Td>9715 Brockbank Dr, Dallas, TX 75220</Td>
          <Td>(214) 350-1633</Td>
          <Td></Td>
          <Td>Association</Td>
          
        </Tr>
        <Tr>
          <Td>Sunny Community Home Care (서니홈케어)</Td>
          <Td>1249M Blalock Rd, Houston, TX 77055</Td>
          <Td>(832) 581-3461</Td>
          <Td>http://sunnyhomecareinc.com/index.php</Td>
          <Td>Home care</Td>
          
        </Tr>
        <Tr>
          <Td>Woori Home Care (우리홈케어)</Td>
          <Td>2625 Old Denton Rd Ste 452, Carrollton, TX 75007</Td>
          <Td>(972) 820-8700</Td>
          <Td></Td>
          <Td>Home care</Td>
          
        </Tr>
        <Tr>
          <Td>Korean American Association of Austin</Td>
          <Td></Td>
          <Td></Td>
          <Td>https://www.facebook.com/KAAGAUSA/</Td>
          <Td></Td>
          
        </Tr>
        
      </Tbody>
    </Table>
  );
} // Static list of dementia care facilities to display below the map - still need to dynamically pull from Firebase