/*@flow*/
import React from 'react';
import './Cards.css';
import CardItem from './CardItem';
//importing all dependiencies, libraries, and subsite js pages by category- Hamilton Nguyen 10/19/2020

//card function are created to return static cards that goes onto the dementia info page. Withinn the function, a total of three cards with disignated classNames are created.- Hamilton Nguyen 10/19/2020
function Cards() {
  return (
    <div className='cards'>
      <h1>치매 정보</h1>
      <div className='cards__container'>
        <div className='cards__wrapper'>
          <ul className='cards__items'>
            <CardItem
              src='images/img-9.jpg'
              text='알츠하이머 병은 시간이 지남에 따라 뇌 세포에 영향을 미치는 유전 적, 생활 방식 및 환경 적 요인과 관련이 있습니다. 질병의 초기 단계에서 건망증과 경미한 혼란이 보입니다. 시간이지나면서 최근의 기억도 지워지기 시작합니다. 진행된 단계 증상은 사람마다 다릅니다. 알츠하이머 병에 대한 치료법은 없습니다. 약물은 일시적으로 일부 증상을 감소 시키거나 일부 사람들의 상태 진행을 늦출 수 있습니다.'
              label='알츠하이머 병'
              path='/services'
            />
            <CardItem
              src='images/img-2.jpg'
              text='기억, 사고에 영향을 미치고 일상 생활을 방해하는 일련의 증상입니다.'
              label='백치'
              path='/services'
            />
            <CardItem
              src='images/img-2.jpg'
              text='과학자들은 알츠하이머 및 관련 치매를 진단, 치료 및 예방할 수있는 잠재적 인 새로운 방법을 식별하는 데 큰 진전을 이루고 있습니다. 이러한 발전은 수천 명의 사람들이 임상 시험 및 기타 연구에 참여했기 때문에 가능합니다.'
              label='치매 연구 및 임상 시험'
              path='/services'
            />
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Cards;