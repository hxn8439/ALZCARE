/*@flow*/
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';



//reactDOM rendering Environment to call App.js - Hamilton Nguyen 10/19/2020
ReactDOM.render(<App />,document.getElementById('root')
);



